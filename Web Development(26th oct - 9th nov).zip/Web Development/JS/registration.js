function registration()
{
    var name = document.getElementById('v1').value;
    var age = document.getElementById('v2').value;
    var email = document.getElementById('v3').value;
    var pwd = document.getElementById('v4').value;
    var cpwd = document.getElementById('v5').value;
    
    var name_crit = /^([0-25])/;
    var age_crit = /^([18-99])/;
}